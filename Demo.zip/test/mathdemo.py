def sum(x,y):
	return x + y
	
def ded(x,y):
	return x - y

