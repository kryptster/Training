def setAge(age):
	if age < 18 or age > 60:
		raise ValueError('Invalid age ....')
	
	

try:	
	setAge(20)
	setAge(15)
except ValueError as e:
	print(e)