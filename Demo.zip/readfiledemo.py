def readFile():
	for line in open("demo.txt","r"):
		print(line.split(','))
	

def writeToFile(filename):
	f = open(filename,"w")
	f.write("This is sample data")
	
if __name__ == "__main__":
	readFile()
	filename=input("Enter the File Name : ")
	writeToFile("writeDemo.txt")
	
	sys.argv[0]