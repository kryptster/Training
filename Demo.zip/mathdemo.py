def add(x,y):
	return x + y
	
def sub(x,y):
	return x - y

def mul(x,y):
	return x * y
	
def main():
	sum = add(10,20)
	print(sum)
	prod = mul(5,10)
	print(prod)
	
	
if __name__ == "__main__":	
	main()
