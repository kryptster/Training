def helloworld():
	print("Hello")
	
if __name__ == '__main__':
	helloworld()