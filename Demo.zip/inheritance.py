class Parent :

	def __init__(self):
		print("Parent init called")
	
	def parentFun(self):
		print("Called Parent Function")
		

class Child(Parent):
	def __init__(self):
		print("Child init called")
		
	def childFun(self):
		print("Called Child Function")
		
obj = Child()
obj.childFun()
obj.parentFun()