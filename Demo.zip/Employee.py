class Employee:

	count = 0  # class variable # static
	def __init__(self,empId,empName):
		self.empId = empId
		self.empName = empName
		Employee.count += 1
	
	def __cmp__(self,other):
		pass
	
	def __str__(self):
		return "Employee : "+str(self.empId) +" "+self.empName
	
	def __del__(self):
		name = self.__class__.__name__
		print("Object Destroyeed : "+name)
	
def main():
	obj1 = Employee(101,"John")
	obj2 = Employee(111, "Jane")
	print(Employee.count)
	
	if hasattr(obj1,"empId"):
		print(getattr(obj1,'empId'))
		delattr(obj1,'empName')
		setattr(obj1,'empName',"Jony")
		print(getattr(obj1,'empName'))
	
	print(obj1)
		
if __name__ == '__main__':
	main()
	


