import mathdemo 

def addSal(basic,da):
	print(mathdemo.add(basic,da))
	
if __name__ == '__main__':
	addSal(20000,5000)